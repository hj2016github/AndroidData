package server;

import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 * Created by Lin_Yang on 2014/12/16.
 */
@WebService
public class HelloWorldImpl implements  HelloWorldWS {

    @Override
    public String sayHello(String name) {
        System.out.println("服务端运行");
        String str="欢迎你："+name;
        System.out.println(str);
        return str;
    }
}
