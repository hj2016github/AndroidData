package server;

import javax.jws.WebMethod;
import javax.jws.WebService;

/**
 * Created by Lin_Yang on 2014/12/16.
 */
@WebService
public interface HelloWorldWS {
    @WebMethod
    public String sayHello(String name);
}
