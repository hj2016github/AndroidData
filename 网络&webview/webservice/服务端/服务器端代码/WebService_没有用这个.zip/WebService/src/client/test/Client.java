package client.test;

import client.HelloWorldImpl;
import client.HelloWorldImplService;

/**
 * Created by Lin_Yang on 2014/12/16.
 */
public class Client {
    public static void main(String args[]){
        HelloWorldImplService helloWorldImplService=new HelloWorldImplService();
        HelloWorldImpl helloWorld= helloWorldImplService.getHelloWorldImplPort();
        String returnStr=  helloWorld.sayHello("先知后觉");
        System.out.println("客户端显示：");
        System.out.println(returnStr);
    }

}
